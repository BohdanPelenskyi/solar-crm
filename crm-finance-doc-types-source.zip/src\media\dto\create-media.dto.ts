export class CreateMediaDto {}
