export class Contact {}
